# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'bd46c443a28713fb6f47f6361c3c49cf80fa0899146ba61bd35b22398d3ca9200a4fd953fee096658c24a5a45d222fe2226155233e1a4d65e7547bf2d85d428d'
